import  pygame
x=pygame.init()
#print(x)
gameWindow=pygame.display.set_mode((1200,600))
# Snake--game-in-python
this is snake geme all tutorials for developing the game
